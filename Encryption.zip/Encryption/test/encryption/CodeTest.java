/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package encryption;

import java.io.File;
import javax.swing.JFileChooser;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author IcarusFlow
 */
public class CodeTest {
    
    public CodeTest() {
    }

    /**
     * Test of randomize method, of class Code.
     */
 

    /**
     * Test of encrypt method, of class Code.
     */
    @Test
    public void testEncrypt() {
        System.out.println("encrypt");
       String content = "ab";
       String replace = null;
        Code instance = new Code();
        for(int i = 0; i < content.length(); i++){
          instance.encrypt(content);
          replace = instance.rep; 
          content = replace;
        }
        
        System.out.println(replace);
      
    }

    /**
     * Test of randomize method, of class Code.
     */
    @Test
    public void testRandomize() {
        System.out.println("randomize");
        int c = 0;
        Code instance = new Code();
        c = instance.randomize(c);
        System.out.println(c);
    }

    /**
     * Test of print method, of class Code.
     */
    
    
}
