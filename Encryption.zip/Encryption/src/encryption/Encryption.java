/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package encryption;

import java.io.File;
import javax.swing.JFileChooser;
import java.util.Scanner;
import java.io.IOException;
import java.util.Arrays;



/**
 *
 * @author IcarusFlow
 */
public class Encryption {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        Code enc = new Code();
        System.out.println("Would you like to encrypt a file?");
        String choice = input.next();
        String content = null;
        String content1 = null;
        
        if ("Y".equals(choice)){
            JFileChooser jfc = new JFileChooser();
            jfc.showDialog(null,"Please Select the File");
            jfc.setVisible(true);
            File filename = jfc.getSelectedFile();
            
            Scanner output = new Scanner(filename);
            content1 = output.toString();
            
            
            
            
            
            for(int i = 0; i < content1.length(); i++){
               enc.encrypt(content1);
               content = enc.rep.toString();
               content1 = content;
                
            }
            System.out.println(content);
            
            
            
        
        }
            

    }

}
            
        
   

    
    

