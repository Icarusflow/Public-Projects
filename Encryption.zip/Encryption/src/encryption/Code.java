/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package encryption;
import java.util.Arrays;
import java.util.Random;

/**
 *
 * @author IcarusFlow
 */
public class Code {
    int c1;
    int c2;
    StringBuilder rep;
    char place;

    
    public Code(){
        c1 = 0;
        c2 = 0;
        rep = null;
        
    }
    
    /**
    * Randomizes an integer
    * @param c
    * @return 
    */
    int randomize(int c){
        Random rand = new Random();
        c = rand.nextInt(260);
        return c;
    }
    /**
     * Assigns a random integer to a character from a text file
     * @param c
     * @param file 
     */
    void encrypt(String file){
                rep = new StringBuilder(file);
               for(int i = 0; i < file.length(); i++){
                if(rep.charAt(i) == 'a' || rep.charAt(i) == 'A'){
                    c1 = randomize(c1);
                    while(c1 > 9){
                        c1 = randomize(c1);
                    }
                    
                    place = rep.charAt(i);
                    rep = new StringBuilder().append(place);
                    rep.insert(i, c1);
                    
                    
                }
                else if(file.contains("B") || file.contains("b")){
                    randomize(c1);
                    while(c1 <= 9 || c1 > 19){
                        randomize(c1);
                    }
                    rep = file.replace("B", Integer.toString(c1));
                    rep = file.replace("b", Integer.toString(c1));
                }
                else if(file.contains("C") || file.contains("c")){
                    randomize(c1);
                    while(c1 <= 20 || c1 > 29){
                        randomize(c1);
                    }
                    rep = file.replace("C", Integer.toString(c1));
                    rep = file.replace("c", Integer.toString(c1));
                }
                else if(file.contains("D") || file.contains("d")){
                    randomize(c1);
                    while(c1 <= 30 || c1 > 39){
                        randomize(c1);
                    }
                    rep = file.replace("D", Integer.toString(c1));
                    rep = file.replace("d", Integer.toString(c1));
                }
                else if(file.contains("E") || file.contains("e")){
                    randomize(c1);
                    while(c1 <= 40 || c1 > 49){
                        randomize(c1);
                    }
                    rep = file.replace("E", Integer.toString(c1));
                    rep = file.replace("e", Integer.toString(c1));
                }
                else if(file.contains("F") || file.contains("f")){
                    randomize(c1);
                    while(c1 <= 50 || c1 > 59){
                        randomize(c1);
                    }
                    rep = file.replace("F", Integer.toString(c1));
                    rep = file.replace("f", Integer.toString(c1));
                }
                else if(file.contains("G") || file.contains("g")){
                    randomize(c1);
                    while(c1 <= 60 || c1 > 69){
                        randomize(c1);
                    }
                    rep = file.replace("G", Integer.toString(c1));
                    rep = file.replace("g", Integer.toString(c1));
                }
                else if(file.contains("H") || file.contains("h")){
                    randomize(c1);
                    while(c1 <= 70 || c1 > 79){
                        randomize(c1);
                    }
                    rep = file.replace("H", Integer.toString(c1));
                    rep = file.replace("h", Integer.toString(c1));
                }
                else if(file.contains("I") || file.contains("i")){
                    randomize(c1);
                    while(c1 <= 80 || c1 > 89){
                        randomize(c1);
                    }
                    rep = file.replace("I", Integer.toString(c1));
                    rep = file.replace("i", Integer.toString(c1));
                }
                else if(file.contains("J") || file.contains("j")){
                    randomize(c1);
                    while(c1 <= 90 || c1 > 99){
                        randomize(c1);
                    }
                    rep = file.replace("J", Integer.toString(c1));
                    rep = file.replace("j", Integer.toString(c1));
                }
                else if(file.contains("K") || file.contains("k")){
                    randomize(c1);
                    while(c1 <= 100 || c1 > 109){
                        randomize(c1);
                    }
                    rep = file.replace("K", Integer.toString(c1));
                    rep = file.replace("k", Integer.toString(c1));
                }
                else if(file.contains("L") || file.contains("l")){
                    randomize(c1);
                    while(c1 <= 110 || c1 > 119){
                        randomize(c1);
                    }
                    rep = file.replace("L", Integer.toString(c1));
                    rep = file.replace("l", Integer.toString(c1));
                }
                else if(file.contains("M") || file.contains("m")){
                    randomize(c1);
                    while(c1 <= 120 || c1 > 129){
                        randomize(c1);
                    }
                    rep = file.replace("M", Integer.toString(c1));
                    rep = file.replace("m", Integer.toString(c1));
                }
                else if(file.contains("N") || file.contains("n")){
                    randomize(c1);
                    while(c1 <= 130 || c1 > 139){
                        randomize(c1);
                    }
                    rep = file.replace("N", Integer.toString(c1));
                    rep = file.replace("n", Integer.toString(c1));
                }
                else if(file.contains("O") || file.contains("o")){
                    randomize(c1);
                    while(c1 <= 140 || c1 > 149){
                        randomize(c1);
                    }
                    rep = file.replace("O", Integer.toString(c1));
                    rep = file.replace("o", Integer.toString(c1));
                }
                else if(file.contains("P") || file.contains("p")){
                    randomize(c1);
                    while(c1 <= 150 || c1 > 159){
                        randomize(c1);
                    }
                    rep = file.replace("P", Integer.toString(c1));
                    rep = file.replace("p", Integer.toString(c1));
                }
                else if(file.contains("Q") || file.contains("q")){
                    randomize(c1);
                    while(c1 <= 160 || c1 > 169){
                        randomize(c1);
                    }
                    rep = file.replace("Q", Integer.toString(c1));
                    rep = file.replace("q", Integer.toString(c1));
                }
                else if(file.contains("R") || file.contains("r")){
                    randomize(c1);
                    while(c1 <= 170 || c1 > 179){
                        randomize(c1);
                    }
                    rep = file.replace("R", Integer.toString(c1));
                    rep = file.replace("r", Integer.toString(c1));
                }
                else if(file.contains("S") || file.contains("s")){
                    randomize(c1);
                    while(c1 <= 180 || c1 > 189){
                        randomize(c1);
                    }
                    rep = file.replace("S", Integer.toString(c1));
                    rep = file.replace("s", Integer.toString(c1));
                }
                else if(file.contains("T") || file.contains("t")){
                    randomize(c1);
                    while(c1 <= 190 || c1 > 199){
                        randomize(c1);
                    }
                    rep = file.replace("T", Integer.toString(c1));
                    rep = file.replace("t", Integer.toString(c1));
                }
                else if(file.contains("U") || file.contains("u")){
                    randomize(c1);
                    while(c1 <= 200 || c1 > 209){
                        randomize(c1);
                    }
                    rep = file.replace("U", Integer.toString(c1));
                    rep = file.replace("u", Integer.toString(c1));
                }
                else if(file.contains("V") || file.contains("v")){
                    randomize(c1);
                    while(c1 <= 210 || c1 > 219){
                        randomize(c1);
                    }
                    rep = file.replace("V", Integer.toString(c1));
                    rep = file.replace("v", Integer.toString(c1));
                }
                else if(file.contains("W") || file.contains("w")){
                    randomize(c1);
                    while(c1 <= 220 || c1 > 229){
                        randomize(c1);
                    }
                    rep = file.replace("W", Integer.toString(c1));
                    rep = file.replace("w", Integer.toString(c1));
                }
                else if(file.contains("X") || file.contains("x")){
                    randomize(c1);
                    while(c1 <= 230 || c1 > 239){
                        randomize(c1);
                    }
                    rep = file.replace("X", Integer.toString(c1));
                    rep = file.replace("x", Integer.toString(c1));
                }
                else if(file.contains("Y") || file.contains("y")){
                    randomize(c1);
                    while(c1 <= 240 || c1 > 249){
                        randomize(c1);
                    }
                    rep = file.replace("Y", Integer.toString(c1));
                    rep = file.replace("y", Integer.toString(c1));
                }
                else if(file.contains("Z") || file.contains("z")){
                    randomize(c1);
                    while(c1 <= 250 || c1 >= 260){
                        randomize(c1);
                    }
                    rep = file.replace("Z", Integer.toString(c1));
                    rep = file.replace("z", Integer.toString(c1));
                }
               
               }
            }
        }
    
    

    

